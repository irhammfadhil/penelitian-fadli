<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- ======= Hero Section ======= -->

  <?php echo $__env->make('section.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main id="main">

    <!-- ======= Why Us Section ======= -->
    <?php echo $__env->make('section.fitur', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ======= About Section ======= -->
    <?php echo $__env->make('section.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ======= F.A.Q Section ======= -->
    <?php echo $__env->make('section.faq', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ======= Services Section ======= -->
    <?php echo $__env->make('section.step', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ======= Testimonials Section ======= -->
    <?php echo $__env->make('section.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ======= Team Section ======= -->
    <?php echo $__env->make('section.article', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ======= Portfolio Section ======= -->
    <?php echo $__env->make('section.gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- ======= Contact Section ======= -->
    <?php echo $__env->make('section.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </main><!-- End #main -->

  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH E:\penelitian-fadli\resources\views/index.blade.php ENDPATH**/ ?>