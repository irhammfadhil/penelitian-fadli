<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="shortcut icon" href="<?php echo e(asset('img/icons/icon-48x48.png')); ?>" />

    <link rel="canonical" href="https://demo-basic.adminkit.io/" />

    <title>Simetri</title>

    <link href="<?php echo e(asset('static/css/app.css')); ?>" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        thead {
            border-top: 2px solid;
            border-bottom: 2px solid;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main">
            <?php echo $__env->make('layouts.navbar-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <main class="content">
                <div class="container-fluid p-0">

                    <h1 class="h3 mb-3">Laporan Umum</h1>

                    <br>
                    <div class="card">
                        <div class="card-body">
                            <h3>General</h3>
                            <hr>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col" class="text-center" style="width: 15%;">Jenis Kelamin</th>
                                            <th scope="col" class="text-center" style="width: 15%;">Jumlah Responden</th>
                                            <th scope="col" class="text-center" style="width: 10%;">D/d</th>
                                            <th scope="col" class="text-center" style="width: 10%;">M/e</th>
                                            <th scope="col" class="text-center" style="width: 10%;">F/f</th>
                                            <th scope="col" class="text-center" style="width: 10%;">Rata-rata Indeks DMF-T</th>
                                            <th scope="col" class="text-center" style="width: 10%;">Rata-rata Indeks def-t</th>
                                            <th scope="col" class="text-center" style="width: 10%;">Rata-rata Indeks RTI Gigi Tetap</th>
                                            <th scope="col" class="text-center" style="width: 10%;">Rata-rata Indeks RTI Gigi Sulung</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="text-center">Laki-laki</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_general; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Laki-laki'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_79 + $jml_decay_lk_912); ?>/<?php echo e($jml_decay_lk_79_anak + $jml_decay_lk_912_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_79 + $jml_missing_lk_912); ?>/<?php echo e($jml_missing_lk_79_anak + $jml_missing_lk_912_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_79 + $jml_filling_lk_912); ?>/<?php echo e($jml_filling_lk_79_anak + $jml_filling_lk_912_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_79+$jml_missing_lk_79+$jml_filling_lk_79 + $jml_decay_lk_912+$jml_missing_lk_912+$jml_filling_lk_912)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_79_anak+$jml_missing_lk_79_anak+$jml_filling_lk_79_anak + $jml_decay_lk_912_anak+$jml_missing_lk_912_anak+$jml_filling_lk_912_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Perempuan</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_general; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Perempuan'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_pr_79 + $jml_decay_pr_912); ?>/<?php echo e($jml_decay_pr_79_anak + $jml_decay_pr_912_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_pr_79 + $jml_missing_pr_912); ?>/<?php echo e($jml_missing_pr_79_anak + $jml_missing_pr_912_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_pr_79 + $jml_filling_pr_912); ?>/<?php echo e($jml_filling_pr_79_anak + $jml_filling_pr_912_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_79+$jml_missing_pr_79+$jml_filling_pr_79 + $jml_decay_pr_912+$jml_missing_pr_912+$jml_filling_pr_912)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_79_anak+$jml_missing_pr_79_anak+$jml_filling_pr_79_anak + $jml_decay_pr_912_anak+$jml_missing_pr_912_anak+$jml_filling_pr_912_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr style="border-top: 2px solid; border-bottom: 2px solid;">
                                            <td class="text-center" colspan="1">Total</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_79 + $jml_decay_lk_912 + $jml_decay_pr_79 + $jml_decay_pr_912); ?>/<?php echo e($jml_decay_lk_79_anak + $jml_decay_lk_912_anak + $jml_decay_pr_79_anak + $jml_decay_pr_912_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_79 + $jml_missing_lk_912 + $jml_missing_pr_79 + $jml_missing_pr_912); ?>/<?php echo e($jml_missing_lk_79_anak + $jml_missing_lk_912_anak + $jml_missing_pr_79_anak + $jml_missing_pr_912_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_79 + $jml_filling_lk_912 + $jml_filling_pr_79 + $jml_filling_pr_912); ?>/<?php echo e($jml_filling_lk_79_anak + $jml_filling_lk_912_anak + $jml_filling_pr_79_anak + $jml_filling_pr_912_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_79+$jml_missing_lk_79+$jml_filling_lk_79 + $jml_decay_lk_912+$jml_missing_lk_912+$jml_filling_lk_912 + $jml_decay_pr_79+$jml_missing_pr_79+$jml_filling_pr_79 + $jml_decay_pr_912+$jml_missing_pr_912+$jml_filling_pr_912)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_79_anak+$jml_missing_lk_79_anak+$jml_filling_lk_79_anak + $jml_decay_lk_912_anak+$jml_missing_lk_912_anak+$jml_filling_lk_912_anak + $jml_decay_pr_79_anak+$jml_missing_pr_79_anak+$jml_filling_pr_79_anak + $jml_decay_pr_912_anak+$jml_missing_pr_912_anak+$jml_filling_pr_912_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                    </tbody>
                                </table>
                                <p style="text-align: right;"><i>Copyright</i> (C) <?php echo e(date('Y')); ?> Simetri. <i>All rights reserved</i></p>
                            </div>
                            <h3>Berdasarkan Kelompok Usia</h3>
                            <hr>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col" class="text-center" style="width: 7.5%;">Kelompok Usia</th>
                                            <th scope="col" class="text-center" style="width: 7.5%;">Jenis Kelamin</th>
                                            <th scope="col" class="text-center" style="width: 15%;">Jumlah Responden</th>
                                            <th scope="col" class="text-center" style="width: 10%;">D/d</th>
                                            <th scope="col" class="text-center" style="width: 10%;">M/e</th>
                                            <th scope="col" class="text-center" style="width: 10%;">F/f</th>
                                            <th scope="col" class="text-center" style="width: 10%;">Rata-rata Indeks DMF-T</th>
                                            <th scope="col" class="text-center" style="width: 10%;">Rata-rata Indeks def-t</th>
                                            <th scope="col" class="text-center" style="width: 10%;">Rata-rata Indeks RTI Gigi Tetap</th>
                                            <th scope="col" class="text-center" style="width: 10%;">Rata-rata Indeks RTI Gigi Sulung</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td rowspan="3" class="text-center">7 tahun</td>
                                            <td class="text-center">Laki-laki</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_klp_usia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Laki-laki' && $q->kategori_umur == 'Usia 7 th'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_7); ?>/<?php echo e($jml_decay_lk_7_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_7); ?>/<?php echo e($jml_missing_lk_7_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_7); ?>/<?php echo e($jml_filling_lk_7_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_7+$jml_missing_lk_7+$jml_filling_lk_7)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_7_anak+$jml_missing_lk_7_anak+$jml_filling_lk_7_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Perempuan</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_klp_usia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Perempuan' && $q->kategori_umur == 'Usia 7 th'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_pr_7); ?>/<?php echo e($jml_decay_pr_7_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_pr_7); ?>/<?php echo e($jml_missing_pr_7_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_pr_7); ?>/<?php echo e($jml_filling_pr_7_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_7+$jml_missing_pr_7+$jml_filling_pr_7)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_7_anak+$jml_missing_pr_7_anak+$jml_filling_pr_7_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Total</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total_by_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->age == 7): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_7 + $jml_decay_pr_7); ?>/<?php echo e($jml_decay_lk_7_anak + $jml_decay_pr_7_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_7 + $jml_missing_pr_7); ?>/<?php echo e($jml_missing_lk_7_anak + $jml_missing_pr_7_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_7 + $jml_filling_pr_7); ?>/<?php echo e($jml_filling_lk_7_anak + $jml_filling_pr_7_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_7+$jml_missing_lk_7+$jml_filling_lk_7+$jml_decay_pr_7+$jml_missing_pr_7+$jml_filling_pr_7)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_7_anak+$jml_missing_lk_7_anak+$jml_filling_lk_7_anak+$jml_decay_pr_7_anak+$jml_missing_pr_7_anak+$jml_filling_pr_7_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td rowspan="3" class="text-center">8 tahun</td>
                                            <td class="text-center">Laki-laki</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_klp_usia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Laki-laki' && $q->kategori_umur == 'Usia 8 th'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_8); ?>/<?php echo e($jml_decay_lk_8_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_8); ?>/<?php echo e($jml_missing_lk_8_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_8); ?>/<?php echo e($jml_filling_lk_8_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_8+$jml_missing_lk_8+$jml_filling_lk_8)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_8_anak+$jml_missing_lk_8_anak+$jml_filling_lk_8_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Perempuan</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_klp_usia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Perempuan' && $q->kategori_umur == 'Usia 8 th'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_pr_8); ?>/<?php echo e($jml_decay_pr_8_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_pr_8); ?>/<?php echo e($jml_missing_pr_8_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_pr_8); ?>/<?php echo e($jml_filling_pr_8_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_8+$jml_missing_pr_8+$jml_filling_pr_8)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_8_anak+$jml_missing_pr_8_anak+$jml_filling_pr_8_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Total</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total_by_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->age == 8): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_8 + $jml_decay_pr_8); ?>/<?php echo e($jml_decay_lk_8_anak + $jml_decay_pr_8_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_8 + $jml_missing_pr_8); ?>/<?php echo e($jml_missing_lk_8_anak + $jml_missing_pr_8_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_8 + $jml_filling_pr_8); ?>/<?php echo e($jml_filling_lk_8_anak + $jml_filling_pr_8_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_8+$jml_missing_lk_8+$jml_filling_lk_8+$jml_decay_pr_8+$jml_missing_pr_8+$jml_filling_pr_8)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_8_anak+$jml_missing_lk_8_anak+$jml_filling_lk_8_anak+$jml_decay_pr_8_anak+$jml_missing_pr_8_anak+$jml_filling_pr_8_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td rowspan="3" class="text-center">9 tahun</td>
                                            <td class="text-center">Laki-laki</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_klp_usia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Laki-laki' && $q->kategori_umur == 'Usia 9 th'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_9); ?>/<?php echo e($jml_decay_lk_9_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_9); ?>/<?php echo e($jml_missing_lk_9_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_9); ?>/<?php echo e($jml_filling_lk_9_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_9+$jml_missing_lk_9+$jml_filling_lk_9)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_9_anak+$jml_missing_lk_9_anak+$jml_filling_lk_9_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Perempuan</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_klp_usia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Perempuan' && $q->kategori_umur == 'Usia 9 th'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_pr_9); ?>/<?php echo e($jml_decay_pr_9_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_pr_9); ?>/<?php echo e($jml_missing_pr_9_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_pr_9); ?>/<?php echo e($jml_filling_pr_9_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_9+$jml_missing_pr_9+$jml_filling_pr_9)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_9_anak+$jml_missing_pr_9_anak+$jml_filling_pr_9_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Total</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total_by_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->age == 9): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_9 + $jml_decay_pr_9); ?>/<?php echo e($jml_decay_lk_9_anak + $jml_decay_pr_9_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_9 + $jml_missing_pr_9); ?>/<?php echo e($jml_missing_lk_9_anak + $jml_missing_pr_9_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_9 + $jml_filling_pr_9); ?>/<?php echo e($jml_filling_lk_9_anak + $jml_filling_pr_9_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_9+$jml_missing_lk_9+$jml_filling_lk_9+$jml_decay_pr_9+$jml_missing_pr_9+$jml_filling_pr_9)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_9_anak+$jml_missing_lk_9_anak+$jml_filling_lk_9_anak+$jml_decay_pr_9_anak+$jml_missing_pr_9_anak+$jml_filling_pr_9_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td rowspan="3" class="text-center">10 tahun</td>
                                            <td class="text-center">Laki-laki</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_klp_usia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Laki-laki' && $q->kategori_umur == 'Usia 10 th'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_10); ?>/<?php echo e($jml_decay_lk_10_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_10); ?>/<?php echo e($jml_missing_lk_10_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_10); ?>/<?php echo e($jml_filling_lk_10_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_10+$jml_missing_lk_10+$jml_filling_lk_10)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_10_anak+$jml_missing_lk_10_anak+$jml_filling_lk_10_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Perempuan</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_klp_usia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Perempuan' && $q->kategori_umur == 'Usia 10 th'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_pr_10); ?>/<?php echo e($jml_decay_pr_10_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_pr_10); ?>/<?php echo e($jml_missing_pr_10_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_pr_10); ?>/<?php echo e($jml_filling_pr_10_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_10+$jml_missing_pr_10+$jml_filling_pr_10)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_10_anak+$jml_missing_pr_10_anak+$jml_filling_pr_10_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Total</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total_by_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->age == 10): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_10 + $jml_decay_pr_10); ?>/<?php echo e($jml_decay_lk_10_anak + $jml_decay_pr_10_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_10 + $jml_missing_pr_10); ?>/<?php echo e($jml_missing_lk_10_anak + $jml_missing_pr_10_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_10 + $jml_filling_pr_10); ?>/<?php echo e($jml_filling_lk_10_anak + $jml_filling_pr_10_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_10+$jml_missing_lk_10+$jml_filling_lk_10+$jml_decay_pr_10+$jml_missing_pr_10+$jml_filling_pr_10)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_10_anak+$jml_missing_lk_10_anak+$jml_filling_lk_10_anak+$jml_decay_pr_10_anak+$jml_missing_pr_10_anak+$jml_filling_pr_10_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td rowspan="3" class="text-center">11 tahun</td>
                                            <td class="text-center">Laki-laki</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_klp_usia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Laki-laki' && $q->kategori_umur == 'Usia 11 th'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_11); ?>/<?php echo e($jml_decay_lk_11_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_11); ?>/<?php echo e($jml_missing_lk_11_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_11); ?>/<?php echo e($jml_filling_lk_11_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_11+$jml_missing_lk_11+$jml_filling_lk_11)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_11_anak+$jml_missing_lk_11_anak+$jml_filling_lk_11_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Perempuan</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_klp_usia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Perempuan' && $q->kategori_umur == 'Usia 11 th'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_pr_11); ?>/<?php echo e($jml_decay_pr_11_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_pr_11); ?>/<?php echo e($jml_missing_pr_11_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_pr_11); ?>/<?php echo e($jml_filling_pr_11_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_11+$jml_missing_pr_11+$jml_filling_pr_11)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_11_anak+$jml_missing_pr_11_anak+$jml_filling_pr_11_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Total</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total_by_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->age == 11): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_11 + $jml_decay_pr_11); ?>/<?php echo e($jml_decay_lk_11_anak + $jml_decay_pr_11_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_11 + $jml_missing_pr_11); ?>/<?php echo e($jml_missing_lk_11_anak + $jml_missing_pr_11_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_11 + $jml_filling_pr_11); ?>/<?php echo e($jml_filling_lk_11_anak + $jml_filling_pr_11_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_11+$jml_missing_lk_11+$jml_filling_lk_11+$jml_decay_pr_11+$jml_missing_pr_11+$jml_filling_pr_11)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_11_anak+$jml_missing_lk_11_anak+$jml_filling_lk_11_anak+$jml_decay_pr_11_anak+$jml_missing_pr_11_anak+$jml_filling_pr_11_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td rowspan="3" class="text-center">12 tahun</td>
                                            <td class="text-center">Laki-laki</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_klp_usia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Laki-laki' && $q->kategori_umur == 'Usia 12 th'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_12); ?>/<?php echo e($jml_decay_lk_12_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_12); ?>/<?php echo e($jml_missing_lk_12_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_12); ?>/<?php echo e($jml_filling_lk_12_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_12+$jml_missing_lk_12+$jml_filling_lk_12)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_12_anak+$jml_missing_lk_12_anak+$jml_filling_lk_12_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Perempuan</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_klp_usia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Perempuan' && $q->kategori_umur == 'Usia 12 th'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_pr_12); ?>/<?php echo e($jml_decay_pr_12_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_pr_12); ?>/<?php echo e($jml_missing_pr_12_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_pr_12); ?>/<?php echo e($jml_filling_pr_12_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_12+$jml_missing_pr_12+$jml_filling_pr_12)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_pr_12_anak+$jml_missing_pr_12_anak+$jml_filling_pr_12_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Total</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total_by_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->age == 12): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_12 + $jml_decay_pr_12); ?>/<?php echo e($jml_decay_lk_12_anak + $jml_decay_pr_12_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_12 + $jml_missing_pr_12); ?>/<?php echo e($jml_missing_lk_12_anak + $jml_missing_pr_12_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_12 + $jml_filling_pr_12); ?>/<?php echo e($jml_filling_lk_12_anak + $jml_filling_pr_12_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_12+$jml_missing_lk_12+$jml_filling_lk_12+$jml_decay_pr_12+$jml_missing_pr_12+$jml_filling_pr_12)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_12_anak+$jml_missing_lk_12_anak+$jml_filling_lk_12_anak+$jml_decay_pr_12_anak+$jml_missing_pr_12_anak+$jml_filling_pr_12_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr style="border-top: 2px solid; border-bottom: 2px solid;">
                                            <td class="text-center" colspan="2">Total</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e($jml_decay_lk_79 + $jml_decay_lk_912 + $jml_decay_pr_79 + $jml_decay_pr_912); ?>/<?php echo e($jml_decay_lk_79_anak + $jml_decay_lk_912_anak + $jml_decay_pr_79_anak + $jml_decay_pr_912_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_missing_lk_79 + $jml_missing_lk_912 + $jml_missing_pr_79 + $jml_missing_pr_912); ?>/<?php echo e($jml_missing_lk_79_anak + $jml_missing_lk_912_anak + $jml_missing_pr_79_anak + $jml_missing_pr_912_anak); ?></td>
                                            <td class="text-center"><?php echo e($jml_filling_lk_79 + $jml_filling_lk_912 + $jml_filling_pr_79 + $jml_filling_pr_912); ?>/<?php echo e($jml_filling_lk_79_anak + $jml_filling_lk_912_anak + $jml_filling_pr_79_anak + $jml_filling_pr_912_anak); ?></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_79 + $jml_decay_lk_912 + $jml_decay_pr_79 + $jml_decay_pr_912+$jml_missing_lk_79 + $jml_missing_lk_912 + $jml_missing_pr_79 + $jml_missing_pr_912+$jml_filling_lk_79 + $jml_filling_lk_912 + $jml_filling_pr_79 + $jml_filling_pr_912)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($jml_decay_lk_79_anak + $jml_decay_lk_912_anak + $jml_decay_pr_79_anak + $jml_decay_pr_912_anak+$jml_missing_lk_79_anak + $jml_missing_lk_912_anak + $jml_missing_pr_79_anak + $jml_missing_pr_912_anak+$jml_filling_lk_79_anak + $jml_filling_lk_912_anak + $jml_filling_pr_79_anak + $jml_filling_pr_912_anak)/$q->jumlah,2)); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti*100,2)); ?> %</b></td>
                                            <td class="text-center"><b><?php echo e(number_format($q->rata_rata_rti_anak*100,2)); ?> %</b></td>
                                            <?php $found = 1; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0/0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <td class="text-center"><b>0%</b></td>
                                            <?php endif; ?>
                                        </tr>
                                    </tbody>
                                </table>
                                <p style="text-align: right;"><i>Copyright</i> (C) <?php echo e(date('Y')); ?> Simetri. <i>All rights reserved</i></p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <footer class="footer">
                <div class="container-fluid">
                    <div class="row text-muted">
                        <div class="col-6 text-start">
                            <p class="mb-0">
                                <a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>Simetri</strong></a> &copy;
                            </p>
                        </div>
                        <div class="col-6 text-end">

                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <script src="<?php echo e(asset('static/js/app.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#listAnak').DataTable();
        });
    </script>
</body>

</html><?php /**PATH D:\penelitian-fadli\resources\views/dashboard-admin/laporan/general.blade.php ENDPATH**/ ?>