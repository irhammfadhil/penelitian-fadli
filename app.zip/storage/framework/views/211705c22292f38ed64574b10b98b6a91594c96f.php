<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="shortcut icon" href="<?php echo e(asset('img/icons/icon-48x48.png')); ?>" />

    <link rel="canonical" href="https://demo-basic.adminkit.io/" />

    <title>Simetri</title>

    <link href="<?php echo e(asset('static/css/app.css')); ?>" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        thead {
            border-top: 2px solid;
            border-bottom: 2px solid;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main">
            <?php echo $__env->make('layouts.navbar-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <main class="content">
                <div class="container-fluid p-0">

                    <h1 class="h3 mb-3">Jumlah Responden</h1>

                    <br>
                    <div class="card">
                        <div class="card-body">
                            
                            <h3>General</h3>
                            <hr>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col" class="text-center" style="width: 50%;">Jenis Kelamin</th>
                                            <th scope="col" class="text-center" style="width: 25%;">N</th>
                                            <th scope="col" class="text-center" style="width: 25%;">%</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="text-center">Laki-laki</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_general; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Laki-laki'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e(number_format(($q->jumlah/$total_responden)*100,1)); ?></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0.0</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">Perempuan</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_general; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->jenis_kelamin == 'Perempuan'): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e(number_format(($q->jumlah/$total_responden)*100,1)); ?></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0.0</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr style="border-top: 2px solid; border-bottom: 2px solid;">
                                            <td class="text-center" colspan="1">Total</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><b>100.0</b></td>
                                            <?php $found = 1; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>100.0</b></td>
                                            <?php endif; ?>
                                        </tr>
                                    </tbody>
                                </table>
                                <p style="text-align: right;"><i>Copyright</i> (C) <?php echo e(date('Y')); ?> Simetri. <i>All rights reserved</i></p>
                            </div>
                            <h3>Berdasarkan Usia</h3>
                            <hr>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col" class="text-center" style="width: 50%;">Usia</th>
                                            <th scope="col" class="text-center" style="width: 25%;">N</th>
                                            <th scope="col" class="text-center" style="width: 25%;">%</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="text-center">7 tahun</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total_by_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->age == 7): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e(number_format(($q->jumlah/$total_responden)*100,1)); ?></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">8 tahun</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total_by_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->age == 8): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e(number_format(($q->jumlah/$total_responden)*100,1)); ?></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">9 tahun</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total_by_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->age == 9): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e(number_format(($q->jumlah/$total_responden)*100,1)); ?></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">10 tahun</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total_by_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->age == 10): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e(number_format(($q->jumlah/$total_responden)*100,1)); ?></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">11 tahun</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total_by_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->age == 11): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e(number_format(($q->jumlah/$total_responden)*100,1)); ?></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td class="text-center">12 tahun</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total_by_age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($q->age == 12): ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><?php echo e(number_format(($q->jumlah/$total_responden)*100,1)); ?></td>
                                            <?php $found = 1; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>0</b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr style="border-top: 2px solid; border-bottom: 2px solid;">
                                            <td class="text-center" colspan="1">Total</td>
                                            <?php $found = 0; ?>
                                            <?php $__currentLoopData = $query_total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="text-center"><b><?php echo e($q->jumlah); ?></b></td>
                                            <td class="text-center"><b><?php echo e(number_format(($q->jumlah/$total_responden)*100,1)); ?></b></td>
                                            <?php $found = 1; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$found): ?>
                                            <td class="text-center"><b>0</b></td>
                                            <td class="text-center"><b>100</b></td>
                                            <?php endif; ?>
                                        </tr>
                                    </tbody>
                                </table>
                                <p style="text-align: right;"><i>Copyright</i> (C) <?php echo e(date('Y')); ?> Simetri. <i>All rights reserved</i></p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <footer class="footer">
                <div class="container-fluid">
                    <div class="row text-muted">
                        <div class="col-6 text-start">
                            <p class="mb-0">
                                <a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>Simetri</strong></a> &copy; <?php echo e(date('Y')); ?>. All rights reserved.
                            </p>
                        </div>
                        <div class="col-6 text-end">

                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <script src="<?php echo e(asset('static/js/app.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#listAnak').DataTable();
        });
    </script>
</body>

</html><?php /**PATH D:\penelitian-fadli\resources\views/dashboard-admin/laporan/responden.blade.php ENDPATH**/ ?>