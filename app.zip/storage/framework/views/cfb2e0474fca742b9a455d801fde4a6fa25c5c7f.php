<section id="testimonials" class="testimonials">
      <div class="container position-relative" data-aos="fade-up">

          <div class="text-center">
            <h3 style="color: #ffffff;">Registrasi</h3>
            <p style="color: #ffffff;"> Untuk bergabung dengan aplikasi Simetri, Silahkan klik tombol berikut.</p>
            <a class="btn btn-primary" href="/register">Daftar</a>
          </div>

      </div>
    </section><!-- End Testimonials Section --><?php /**PATH D:\penelitian-fadli\resources\views/section/register.blade.php ENDPATH**/ ?>