<nav id="sidebar" class="sidebar js-sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="index.html">
          <span class="align-middle">Serat</span>
        </a>

				<ul class="sidebar-nav">
					<li class="sidebar-header">
						Halaman
					</li>
			<?php if(Auth::user()->is_admin == 0): ?>

					<li class="sidebar-item active">
						<a class="sidebar-link" href="/dashboard/user">
              <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
            </a>
					</li>
					
					<li class="sidebar-item">
						<a class="sidebar-link" href="/biodata">
              <i class="align-middle" data-feather="user"></i> <span class="align-middle">Biodata dan Foto Gigi</span>
            </a>
					</li>
			<?php else: ?>
			<li class="sidebar-item active">
						<a class="sidebar-link" href="/dashboard/admin">
              <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
            </a>
			</li>
			<li class="sidebar-item">
						<a class="sidebar-link" href="/daftar-anak">
              <i class="align-middle" data-feather="user"></i> <span class="align-middle">Daftar Anak</span>
            </a>
			</li>
			<?php endif; ?>

			</div>
		</nav><?php /**PATH E:\penelitian-fadli\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>