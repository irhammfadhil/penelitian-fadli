<!DOCTYPE html>
<html>

<head>
    <title>Laporan a.n. <?php echo e($user->name); ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>

<body>
    <style type="text/css">
        table tr td,
        table tr th {
            font-size: 9pt;
        }

        .page_break {
            page-break-before: always;
        }

        .center {
            text-align: center;
        }

        .center img {
            display: block;
        }
    </style>
    <style>
        #box {
            box-sizing: content-box;
            width: 600px;
            height: 40px;
            padding: 20px;
            border: 3px solid black;
        }
    </style>
    <style type="text/css">
        html,
        body,
        h1,
        h2,
        h3,
        h4,
        h5,
        p {
            font-family: "Times New Roman", Times, serif;
        }

        .row {
            clear: both;
        }

        .col-lg-1 {
            width: 8%;
            float: left;
        }

        .col-lg-2 {
            width: 16%;
            float: left;
        }

        .col-lg-3 {
            width: 25%;
            float: left;
        }

        .col-lg-4 {
            width: 33%;
            float: left;
        }

        .col-lg-5 {
            width: 42%;
            float: left;
        }

        .col-lg-6 {
            width: 50%;
            float: left;
        }

        .col-lg-7 {
            width: 58%;
            float: left;
        }

        .col-lg-8 {
            width: 66%;
            float: left;
        }

        .col-lg-9 {
            width: 75%;
            float: left;
        }

        .col-lg-10 {
            width: 83%;
            float: left;
        }

        .col-lg-11 {
            width: 92%;
            float: left;
        }

        .col-lg-12 {
            width: 100%;
            float: left;
        }

        hr.new1 {
            border-top: 1px solid black;
        }

        .page_break {
            page-break-before: always;
        }
    </style>
    <div class="row">
        <div class="col-lg-2">
            <img src="<?php echo e(public_path('logo-unej.png')); ?>" style="width: auto; height: 125px;">
        </div>
        <div class="col-lg-9">
            <h3 class="text-center">Laporan Hasil Diagnosis</h3>
            <h3 class="text-center">SIMETRI</h3>
            <h5 class="text-center" style="font-size:18px;">Sistem Informasi Penilaian Required Treatment Index Gigi Anak</h5>
            <h5 class="text-center" style="font-size:20px;">Fakultas Kedokteran Gigi Universitas Jember</h5>
        </div>
    </div>
    <br><br><br><br><br><br>
    <hr>
    <h5>Informasi Pribadi</h5>
    <div class="row">
        <div class="col-lg-3">
            Nama
        </div>
        <div class="col-lg-9">
            : <?php echo e($user->name); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-lg-3">
            Alamat Email
        </div>
        <div class="col-lg-9">
            : <?php echo e($user->email); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-lg-3">
            Waktu Pendaftaran
        </div>
        <div class="col-lg-9">
            : <?php echo e($tanggal_daftar); ?>

        </div>
    </div>
    <?php if($biodata): ?>
    <div class="row">
        <div class="col-lg-3">
            Jenis Kelamin
        </div>
        <div class="col-lg-9">
            : <?php echo e($biodata->gender); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-lg-3">
            Tempat dan Tanggal Lahir
        </div>
        <div class="col-lg-9">
            : <?php echo e($biodata->birth_place); ?>, <?php echo e($tanggal_lahir); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-lg-3">
            Sekolah
        </div>
        <div class="col-lg-9">
            : <?php echo e($biodata->id_sekolah); ?>

        </div>
    </div>
    <br>
    <?php endif; ?>
    <?php if($ortu): ?>
    <hr>
    <h5>Informasi Orang Tua</h5>
    <div class="row">
        <div class="col-lg-3">
            Nama Orang Tua
        </div>
        <div class="col-lg-9">
            : <?php echo e($ortu->name_ortu); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-lg-3">
            Alamat Orang Tua
        </div>
        <div class="col-lg-9">
            : <?php echo e($ortu->address); ?>, RT <?php echo e($ortu->rt); ?> RW <?php echo e($ortu->rw); ?>, <?php echo e($ortu->desa); ?>, <?php echo e($ortu->kecamatan); ?>, Kabupaten
            Jember
        </div>
    </div>
    <div class="row">
        <div class="col-lg-3">
            Pendidikan Orang Tua
        </div>
        <div class="col-lg-9">
            : <?php echo e($ortu->pendidikan_terakhir); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-lg-3">
            Pekerjaan Orang Tua
        </div>
        <div class="col-lg-9">
            : <?php echo e($ortu->pekerjaan); ?>

        </div>
    </div>
    <br>
    <?php endif; ?>
    
    <?php if($diagnosis): ?>
    <h5>Diagnosis</h5>
    <hr>
    <div class="row">
        <div class="col-lg-12">
            D/d: <b><?php echo e($sum_decay_tetap); ?>/<?php echo e($sum_decay_susu); ?></b> M/e:
            <b><?php echo e($sum_missing_tetap); ?>/<?php echo e($sum_missing_susu); ?></b> F/f: <b><?php echo e($sum_filling_tetap); ?>/<?php echo e($sum_filling_susu); ?></b>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-2">DMFT: <b><?php echo e($user->dmft_score); ?></b></div>
        <div class="col-lg-8">Kriteria DMFT: <b><?php echo e($kriteria_dmft); ?></b></div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-2">def-t: <b><?php echo e($user->deft_score); ?></b></div>
        <div class="col-lg-8">Kriteria def-t: <b><?php echo e($kriteria_deft); ?></b></div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-12">
            <?php if($user->dmft_score == 0): ?>
            RTI Gigi Tetap: <b>0%</b>
            <?php else: ?>
            RTI Gigi Tetap: <b><?php echo e(number_format($sum_decay_tetap/$user->dmft_score, 2)*100); ?>%</b>
            <?php endif; ?>
            <br>
            <?php if($user->deft_score == 0): ?>
            RTI Gigi Sulung: <b>0%</b>
            <?php else: ?>
            RTI Gigi Sulung: <b><?php echo e(number_format($sum_decay_susu/$user->deft_score, 2)*100); ?>%</b>
            <?php endif; ?>
            <br><br>
        </div>
    </div>
    <h5>Saran</h5>
    <hr>
    <div class="row">
        <div class="col-lg-12">
            <?php echo e($user->comments); ?>

        </div>
    </div>
    <?php endif; ?>
</body>

</html><?php /**PATH D:\penelitian-fadli\resources\views/pdf/report.blade.php ENDPATH**/ ?>