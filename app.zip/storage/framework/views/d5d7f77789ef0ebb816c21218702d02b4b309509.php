<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="<?php echo e(asset('img/icons/icon-48x48.png')); ?>" />

	<link rel="canonical" href="https://demo-basic.adminkit.io/" />

	<title>Simetri</title>

	<link href="<?php echo e(asset('static/css/app.css')); ?>" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
	<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>

<body>
	<div class="wrapper">
		<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="main">
			<?php echo $__env->make('layouts.navbar-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Detail Anak</h1>
					
					<br>
					<div class="card">
						<div class="card-body">
							<h3>Detail Anak</h3>
							<br>
							<h4>Informasi Pribadi</h4>
							<div class="row">
								<div class="col-lg-6">Nama</div>
								<div class="col-lg-6">: <?php echo e($user->name); ?></div>
							</div>
							<div class="row">
								<div class="col-lg-6">Nama Pengguna</div>
								<div class="col-lg-6">: <?php echo e($user->username); ?></div>
							</div>
							<div class="row">
								<div class="col-lg-6">Email</div>
								<div class="col-lg-6">: <?php echo e($user->email); ?></div>
							</div>
							<hr>
							<?php if($biodata): ?>
							<h4>Biodata</h4>
							<div class="row">
								<div class="col-lg-6">Jenis Kelamin</div>
								<div class="col-lg-6">: <?php echo e($biodata->gender); ?></div>
							</div>
							<div class="row">
								<div class="col-lg-6">Tempat dan Tanggal Lahir</div>
								<div class="col-lg-6">: <?php echo e($biodata->birth_place); ?>, <?php echo e($biodata->birth_date); ?></div>
							</div>
							<hr>
							<?php endif; ?>
							<?php if($ortu): ?>
							<h4>Data Orang Tua</h4>
							<div class="row">
								<div class="col-lg-6">Nama Orang Tua</div>
								<div class="col-lg-6">: <?php echo e($ortu->name_ortu); ?></div>
							</div>
							<div class="row">
								<div class="col-lg-6">No. HP Orang Tua</div>
								<div class="col-lg-6">: <?php echo e($ortu->phone); ?></div>
							</div>
							<div class="row">
								<div class="col-lg-6">Alamat</div>
								<div class="col-lg-6">: <?php echo e($ortu->address); ?>, RT <?php echo e($ortu->rt); ?> RW <?php echo e($ortu->rw); ?> DESA <?php echo e($ortu->desa); ?> KECAMATAN <?php echo e($ortu->kecamatan); ?> KABUPATEN JEMBER JAWA TIMUR</div>
							</div>
							<hr>
							<?php endif; ?>
							<?php if($foto): ?>
							<h4>Foto Gigi</h4>
							<ul class="nav nav-tabs" id="myTab" role="tablist">
							<li class="nav-item" role="presentation">
								<button class="nav-link active" id="senyum-penuh-tab" data-bs-toggle="tab" data-bs-target="#senyum-penuh" type="button" role="tab" aria-controls="home" aria-selected="true">Senyum Penuh</button>
							</li>
							<li class="nav-item" role="presentation">
								<button class="nav-link" id="tampak-depan-tab" data-bs-toggle="tab" data-bs-target="#tampak-depan" type="button" role="tab" aria-controls="profile" aria-selected="false">Tampak Depan</button>
							</li>
							<li class="nav-item" role="presentation">
								<button class="nav-link" id="tampak-kiri-tab" data-bs-toggle="tab" data-bs-target="#tampak-kiri" type="button" role="tab" aria-controls="contact" aria-selected="false">Tampak Kiri</button>
							</li>
							<li class="nav-item" role="presentation">
								<button class="nav-link" id="tampak-atas-tab" data-bs-toggle="tab" data-bs-target="#tampak-atas" type="button" role="tab" aria-controls="contact" aria-selected="false">Tampak Atas</button>
							</li>
							<li class="nav-item" role="presentation">
								<button class="nav-link" id="tampak-kanan-tab" data-bs-toggle="tab" data-bs-target="#tampak-kanan" type="button" role="tab" aria-controls="contact" aria-selected="false">Tampak Kanan</button>
							</li>
							<li class="nav-item" role="presentation">
								<button class="nav-link" id="tampak-bawah-tab" data-bs-toggle="tab" data-bs-target="#tampak-kanan" type="button" role="tab" aria-controls="contact" aria-selected="false">Tampak Bawah</button>
							</li>
							</ul>
							<div class="tab-content" id="myTabContent">
								<div class="tab-pane fade show active" id="senyum-penuh" role="tabpanel" aria-labelledby="senyum-penuh-tab">
									<br>
									<img src="<?php echo e(asset($foto->foto_senyum)); ?>" class="img-fluid">
									<br>
									<i>Tanggal Pengambilan: <?php echo e($foto->date_taken_senyum); ?></i>
								</div>
								<div class="tab-pane fade" id="tampak-depan" role="tabpanel" aria-labelledby="tampak-depan-tab">
									<br>
									<img src="<?php echo e(asset($foto->foto_depan)); ?>" class="img-fluid">
									<br>
									<i>Tanggal Pengambilan: <?php echo e($foto->date_taken_depan); ?></i>
								</div>
								<div class="tab-pane fade" id="tampak-kiri" role="tabpanel" aria-labelledby="tampak-kiri-tab">
									<br>
									<img src="<?php echo e(asset($foto->foto_kiri)); ?>" class="img-fluid">
									<br>
									<i>Tanggal Pengambilan: <?php echo e($foto->date_taken_kiri); ?></i>
								</div>
								<div class="tab-pane fade" id="tampak-atas" role="tabpanel" aria-labelledby="tampak-atas-tab">
									<br>
									<img src="<?php echo e(asset($foto->foto_atas)); ?>" class="img-fluid">
									<br>
									<i>Tanggal Pengambilan: <?php echo e($foto->date_taken_atas); ?></i>
								</div>
								<div class="tab-pane fade" id="tampak-kanan" role="tabpanel" aria-labelledby="tampak-kanan-tab">
									<br>
									<img src="<?php echo e(asset($foto->foto_kanan)); ?>" class="img-fluid">
									<br>
									<i>Tanggal Pengambilan: <?php echo e($foto->date_taken_kanan); ?></i>
								</div>
								<div class="tab-pane fade" id="tampak-bawah" role="tabpanel" aria-labelledby="tampak-bawah-tab">
									<br>
									<img src="<?php echo e(asset($foto->foto_bawah)); ?>" class="img-fluid">
									<br>
									<i>Tanggal Pengambilan: <?php echo e($foto->date_taken_bawah); ?></i>
								</div>
							</div>
							<?php endif; ?>
							<hr>
							<div class="row">
								<div class="col-6">
									<h4>Odontogram</h4>
								</div>
								<div class="col-6">
									<!-- Button trigger modal -->
									<button type="button" class="btn btn-primary float-end" data-bs-toggle="modal" data-bs-target="#exampleModal">
									Diagnosis Baru
									</button>
								</div>
							</div>

							<br>
						
							<table class="table table-bordered table-hover">
								<thead class="thead-dark">
									<tr>
									<th scope="col">ID Gigi</th>
									<th scope="col">Diagnosis</th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $id_gigi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
									<th scope="row"><?php echo e($i); ?></th>
									<td>
										<?php $__currentLoopData = $odontogram; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($o->id_gigi == $i): ?>
										<?php echo e($o->region->region_code); ?> <?php echo e($o->diagnosis->diagnosis_code); ?>

										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>

							<!-- Modal -->
							<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog modal-xl">
								<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title" id="exampleModalLabel">Diagnosis Baru</h5>
									<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
								</div>
								<form action="/odontogram/submit" method="post">
								<div class="modal-body">
									<?php echo csrf_field(); ?>
									<input type="hidden" id="usersId" name="usersId" value="">
									<div class="mb-3">
										<label for="exampleInputEmail1" class="form-label">ID Gigi</label>
										<select class="form-select" aria-label="Default select example" name="gigi" id="gigi">
											<option selected>Pilih ID Gigi...</option>
											<?php $__currentLoopData = $id_gigi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
											<option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
									<div class="mb-3">
										<label for="exampleInputEmail1" class="form-label">Regio</label>
										<select class="form-select" aria-label="Default select example" name="regio" id="regio">
											<option selected>Pilih Regio...</option>
											<?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
											<option value="<?php echo e($r->id); ?>"><?php echo e($r->region_code); ?> - <?php echo e($r->region_name); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
									<div class="mb-3">
										<label for="exampleInputEmail1" class="form-label">Diagnosis</label>
										<select class="form-select" aria-label="Default select example" name="diagnosis" id="diagnosis">
											<option selected>Pilih Diagnosis...</option>
											<?php $__currentLoopData = $diagnosis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
											<option value="<?php echo e($d->id); ?>"><?php echo e($d->diagnosis_code); ?> - <?php echo e($d->diagnosis_arti); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
									<div class="mb-3">
										<label for="exampleFormControlTextarea1" class="form-label">Catatan</label>
										<textarea class="form-control" id="catatan" name="catatan" rows="3"></textarea>
									</div>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
									<button type="submit" class="btn btn-primary">Submit</button>
								</div>
								</form>
								</div>
							</div>
							</div>
						</div>
					</div>
				</div>
			</main>

			<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<p class="mb-0">
								<a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>Simetri</strong></a> &copy;
							</p>
						</div>
						<div class="col-6 text-end">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Support</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Help Center</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Privacy</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Terms</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>

	<script src="<?php echo e(asset('static/js/app.js')); ?>"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	<script>
		$(document).ready( function () {
			$('#listAnak').DataTable();
			//triggered when modal is about to be shown
			$('#exampleModal').on('show.bs.modal', function(e) {
				$(".modal-body #usersId").val(<?php echo e(app('request')->input('id')); ?>);
			});
		} );
	</script>
	<style>
		svg{border:1px solid; width:50px}
		use{fill:white;}
		use:hover{fill:gold}
	</style>
</body>

</html><?php /**PATH E:\penelitian-fadli\resources\views/dashboard-admin/detail-anak.blade.php ENDPATH**/ ?>