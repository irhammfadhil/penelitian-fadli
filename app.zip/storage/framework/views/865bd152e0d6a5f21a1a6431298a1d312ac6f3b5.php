<section id="testimonials" class="testimonials">
      <div class="container position-relative" data-aos="fade-up">

          <div class="text-center">
            <h3>Registrasi</h3>
            <p> Untuk bergabung dengan aplikasi SERAT, Silahkan klik tombol berikut.</p>
            <a class="btn btn-primary" href="/register">Daftar</a>
          </div>

      </div>
    </section><!-- End Testimonials Section --><?php /**PATH E:\penelitian-fadli\resources\views/section/register.blade.php ENDPATH**/ ?>