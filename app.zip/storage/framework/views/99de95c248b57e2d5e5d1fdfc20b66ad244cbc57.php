<section class="wrapper team section-bg">
  <div class="container-fostrap">
    <div class="section-title">
      <h2 data-aos="fade-up">Artikel</h2>
      <p data-aos="fade-up">Hidup sehat dimulai dengan gigi yang lebih sehat.</p>
    </div>
    <div class="content">
      <div class="container">
        <div class="row">
          <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
            <div class="card">
              <a class="img-card" href="<?php echo e($a->image); ?>">
                <img src="<?php echo e(asset($a->image)); ?>" class="img-fluid" />
              </a>
              <div class="card-content">
                <h4 class="card-title">
                  <a href="<?php echo e(url('')); ?>/article/<?php echo e($a->link); ?>"> <?php echo e($a->title); ?>

                  </a>
                </h4>
              </div>
              <div class="card-read-more">
                <a href="<?php echo e(url('')); ?>/article/<?php echo e($a->link); ?>" class="btn btn-link btn-block">
                  Baca Selengkapnya
                </a>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
    <br>
    <div class="article-more" style="text-align: center;">
      <a class="btn btn-primary btn-lg" href="/article" role="button">Baca Semua Artikel</a>
    </div>
  </div>
</section><?php /**PATH D:\penelitian-fadli\resources\views/section/article.blade.php ENDPATH**/ ?>