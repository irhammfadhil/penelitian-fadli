  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center" style="background-color: #1d443f;">
    <div class="container d-flex align-items-center justify-content-between"> 

      <div class="logo">
        <!-- Uncomment below if you prefer to use an image logo -->
       <a href="/"><h1 style="color: #f7eb3a;">SIMETRI</h1></a>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="/">Beranda</a></li>
          <li><a class="nav-link scrollto" href="/cara-penggunaan">Cara Penggunaan</a></li>
          <li><a class="nav-link scrollto" href="/artikel">Artikel</a></li>
          <li><a class="nav-link scrollto" href="/tanya-jawab">Tanya Jawab</a></li>
          <li><a class="nav-link scrollto" href="/login">Daftar</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->