<section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="container" data-aos="fade-in">
      <h1>SELAMAT DATANG di <b style="color: #f7eb3a;">SIMETRI</b></h1>
      <h2>Aplikasi Penilaian Indeks Kebutuhan Perawatan Gigi Anak </h2>
    </div>
  </section><!-- End Hero -->