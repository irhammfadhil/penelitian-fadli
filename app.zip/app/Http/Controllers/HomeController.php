<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index() {
        return view('index');
    }
    public function getArtikel() {
        return view('artikel');
    }
    public function getCaraPenggunaan() {
        return view('cara-penggunaan');
    }
}
